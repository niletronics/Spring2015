To Run the code give the following commands or run, runall.sh

>make compile1
>make compile2
>make compile3
>make simulate top=hw2_tb
>make simulate top=ipv6_module
>make simulate top=partaddtb