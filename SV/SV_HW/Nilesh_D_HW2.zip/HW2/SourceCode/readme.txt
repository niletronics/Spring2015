Steps to run the homework program
> Put data.data file at the same place as that of work directory

Steps to execute test without debug information
1. Run the script runlinux.sh to run all the test-cases without debug information
> sh runlinux.sh

Steps to execute test with debug information
2. sh runlinux_debug.sh

