All the source code resides in Directory SourceCode
To run the code please follow the steps as below:

For Windows :
Open QuestaSim
Copy Attached NileshDattaniHW1 to a known place and Browse to the same.
Run the do file to make environment


For Redhat/Linux :
There is a makefile for this environment for this

1. To run all and see summary (Includes compile, simulate, run and clean) : Default Case
> chmod 777 *.sh
> ./runlinux.sh

2. To Run all with debug information 
> chmod 777 *.sh
> ./runlinux_debug.sh






