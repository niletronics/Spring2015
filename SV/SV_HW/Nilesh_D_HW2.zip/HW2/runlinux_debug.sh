make clean
make env
make compile
make debug top=tb_8 
make debug top=tb_16

