make clean
make env
make compile
make simulate top=tb_8 
make simulate top=tb_16

